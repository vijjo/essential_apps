# -*- coding: utf-8 -*-

import random

from anki.hooks import addHook

def fmod_random(txt, extra, context, tag, fullname):
    return random.choice([x.strip() for x in txt.split(',')])

addHook('fmod_random', fmod_random)
