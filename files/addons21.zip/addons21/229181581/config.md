**height_or_width:** Image dimension to contrain. Possible values: "height", "width", or "both".

**max-height**: Maximum image height.

**max-width**: Maximum image width.
