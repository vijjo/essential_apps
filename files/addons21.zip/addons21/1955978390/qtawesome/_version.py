version_info = (0, 5, 0, 'dev0')
__version__ = '.'.join(map(str, version_info))
