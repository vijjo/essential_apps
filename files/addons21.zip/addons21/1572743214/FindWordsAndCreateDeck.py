from aqt import mw, utils
from aqt.qt import *
from aqt import editor
from anki import notes
from anki.utils import intTime, ids2str
import platform


class AddonDialog(QDialog):

    """Main Options dialog"""
    def __init__(self):
        QDialog.__init__(self, parent=mw)
        self.path = None
        self.deck = None
        self._setup_ui()


    def _handle_button(self):
        dialog = OpenFileDialog()
        self.path = dialog.filename
        if self.path is not None:
            utils.showInfo("Choose file successful.")


    def _setup_ui(self):
        """Set up widgets and layouts"""
        button_label = QLabel("Choose file")
        deck_label = QLabel("Choose deck")

        self.button = QPushButton('Choose file')
        self.button.clicked.connect(self._handle_button)
        self.deck_selection = QComboBox()
        self.deck_selection.addItems(sorted(mw.col.decks.allNames()))

        grid = QGridLayout()
        grid.setSpacing(10)
        grid.addWidget(button_label, 1, 0, 1, 1)
        grid.addWidget(self.button, 1, 1, 1, 2)
        grid.addWidget(deck_label, 2, 0, 1, 1)
        grid.addWidget(self.deck_selection, 2, 1, 1, 2)

        # Main button box
        button_box = QDialogButtonBox(QDialogButtonBox.Ok
                        | QDialogButtonBox.Cancel)
        button_box.accepted.connect(self._on_accept)
        button_box.rejected.connect(self._on_reject)

        # Main layout
        l_main = QVBoxLayout()
        l_main.addLayout(grid)
        l_main.addWidget(button_box)
        self.setLayout(l_main)
        self.setMinimumWidth(360)
        self.setWindowTitle('Find words and create deck')


    def _on_accept(self):

        def move_card(ids, deck_name="Created Deck"):
            mw.checkpoint(_("Change Deck"))
            mod = intTime()
            did = mw.col.decks.id(deck_name)
            usn = mw.col.sched.col.usn()
            scids = ids2str(ids)
            mw.col.sched.remFromDyn(ids)
            mw.col.sched.col.db.execute("""
                update cards set usn=?, mod=?, did=? where id in """ + scids,
                                usn, mod, did)
            utils.showInfo("Move cards successfully")
            mw.reset()
            self.close()
        
        self.deck = self.deck_selection.currentText()

        if self.path is not None and self.deck is not None:
            deck_name = self.path.split('/')[-1]
            with open(self.path) as f:
                cards = []
                not_found_words = []
                for word in f:
                    if word.strip() == '':
                        continue
                    query = '"deck:{}" "Word:{}"'.format(self.deck, word.strip())
                    a = mw.col.findCards(query=query)
                    if len(a) == 0:
                        not_found_words.append(word)
                    cards.extend(a)
                if len(not_found_words) > 0:
                    notif = '\n'.join([word.strip() for word in not_found_words])
                    utils.showText("Words that are not in the deck: " + notif)
                if len(cards) == 0:
                    utils.showInfo("Cannot find these words in this deck.")
                    return
                move_card(cards, deck_name)


    def _on_reject(self):
        self.close()


class OpenFileDialog(QDialog):

    def __init__(self):
        QDialog.__init__(self, mw)
        self.title = 'Open file'
        self.left = 10
        self.top = 10
        self.width = 640
        self.height = 480
        self.filename = None
        self._init_ui()
    

    def _init_ui(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)
        self.filename = self._get_file()
        # self.exec_()
    

    def _get_file(self):
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog
        if platform.system() == 'Windows':
            directory = "C:\\Users\\Admin\\Desktop"
        else:
            directory = "~/Desktop/"
        try:
            path = QFileDialog.getOpenFileName(self, "Open File", directory, "All Files (*)", options=options)
            if path:
                return path
            else:
                utils.showInfo("Cannot open this file.")
        except:
            utils.showInfo("Cannot open this file.")
            return None


def display_dialog():
    dialog = AddonDialog()
    dialog.exec_()

    
action = QAction("Find words and create deck", mw)
action.triggered.connect(display_dialog)
mw.form.menuTools.addAction(action)