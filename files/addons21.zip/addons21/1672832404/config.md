Two things can be configured:

* 'NoteIdFieldName': The name you picked for the first field. The standard “Note ID” has worked well for me.
* 'ShowMenu': Whether the menu item should appear. Once you have added the note id to your old cards, you don’t really need the “Add note id” item cluttering up the menu. Change this value to “false” then.
