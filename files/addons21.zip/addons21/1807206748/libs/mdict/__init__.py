from .mdict_query import IndexBuilder
