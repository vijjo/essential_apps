# -*- coding: utf-8 -*-

# Copyright: (c) 2018 hkr <hkrysg@gmail.com>

from anki.hooks import addHook
from aqt import mw
from aqt.qt import *
from functools import partial


def create_tags_submenu(note, root_menu, editor=None):

    submenu = QMenu(_('Tags'), root_menu)

    # チェックボックスとラベル上以外のスペースをクリックしても
    # コンテキストメニューを閉じないようにする
    submenu.mouseReleaseEvent = lambda *_: None

    if editor:
        submenu.aboutToHide.connect(editor.updateTags)

    root_menu.addMenu(submenu)
    all_tag_list = sorted(mw.col.tags.all())
    current_tags = note.tags

    @pyqtSlot(str, QObject, bool)
    def on_checkbox_toggled(tag_str, checkbox, checked):

        # ラベルの太字をON/OFF
        font = QFont()
        font.setBold(checked)
        checkbox.setFont(font)

        if checked:
            note.addTag(tag_str)
        else:
            note.delTag(tag_str)

        # addModeがTrueの時2回目以降のタグ操作が正しく反映されないから
        # 一時的にaddModeをFalseにして対処
        if editor:
            editor.addMode = False
            editor.updateTags()
            editor.addMode = True

        note.flush()

    # チェックボックスを操作してもコンテキストメニューを閉じないようにする
    # Based on:
    # https://stackoverflow.com/a/34733462
    # https://stackoverflow.com/a/2054884
    for tag in all_tag_list:

        cb = QCheckBox(tag.ljust(20), submenu)

        # 現在設定されているタグに当てはまればチェックを入れてラベルを太字にする
        if tag in current_tags:
            cb.setChecked(True)
            font = QFont()
            font.setBold(True)
            cb.setFont(font)

        cb.toggled.connect(partial(on_checkbox_toggled, tag, cb))
        checkable_action = QWidgetAction(submenu)
        checkable_action.setDefaultWidget(cb)

        submenu.addAction(checkable_action)


def ankiWebView_and_reviewer_contextMenuEvent_wrapper(self, menu):

    if mw.state != 'review':
        return
    target_note = mw.reviewer.card.note()
    create_tags_submenu(target_note, menu)


def editorWebView_contextMenuEvent_wrapper(self, menu):

    target_note = self.editor.note

    # ノートを連続して追加する時にタグの履歴がある場合、
    # 一度もタグ入力エリアにフォーカスを移さないでコンテキストメニューを出すと
    # タグ入力エリアの状態がコンテキストメニューに反映されないので、saveTags()を実行して対応
    if self.editor.addMode and self.editor.tags.text():
        self.editor.saveTags()

    create_tags_submenu(target_note, menu, editor=self.editor)


addHook("Reviewer.contextMenuEvent", ankiWebView_and_reviewer_contextMenuEvent_wrapper)
addHook("AnkiWebView.contextMenuEvent", ankiWebView_and_reviewer_contextMenuEvent_wrapper)
addHook("EditorWebView.contextMenuEvent", editorWebView_contextMenuEvent_wrapper)
