if __name__ != "crowd_anki":
    """
    This is to avoid doing init when calling things from tests
    """
    from . import main
