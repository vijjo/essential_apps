# -*- coding: utf-8 -*-
#
# Entry point for the add-on into Anki
# Please do not edit this if you do not know what you are doing.
# Hierarchical Tags Addon: https://github.com/pneff/anki-hierarchical-tags
# Copyright: 2014(c) Patrice Neff http://patrice.ch/>
# Ported to Anki 2.1 by Frodo 07/10/2017
# This addon is licensed under the same license as Anki itself (GNU Affero General Public License 3)

from . import hierarchical_tags